import { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './components/Header';       
import RecipeCard from './components/RecipeCard';
import RecipeForm from './components/RecipeForm'; 

const API_BASE_URL = 'http://localhost:5046/api';

function App() {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null); 
  const [selectedImage, setSelectedImage] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [formData, setFormData] = useState({
    title: '', description: '', prepTimeMinutes: 0, cookTimeMinutes: 0, categoryId: 1
  });
  
  const [instructionSteps, setInstructionSteps] = useState(['']); 
  const [ingredientsList, setIngredientsList] = useState([{ name: '', quantity: '' }]);

  useEffect(() => {
    axios.get(`${API_BASE_URL}/recipes`) 
      .then(response => {
        setRecipes(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error("There was an error fetching the recipes!", error);
        setLoading(false);
      });
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this recipe?")) {
      axios.delete(`${API_BASE_URL}/recipes/${id}`)
        .then(() => setRecipes(recipes.filter(recipe => recipe.id !== id)))
        .catch(error => {
          console.error("There was an error deleting the recipe!", error);
          alert("Failed to delete recipe. Check console.");
        });
    }
  };

  const handleEditClick = (recipe) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setFormData({
      title: recipe.title, description: recipe.description,
      prepTimeMinutes: recipe.prepTimeMinutes, cookTimeMinutes: recipe.cookTimeMinutes, categoryId: recipe.categoryId || 1
    });

    if (recipe.instructions) {
      const stepArray = recipe.instructions.split('\n').map(step => step.replace(/^\d+\.\s*/, '').trim());
      setInstructionSteps(stepArray.length > 0 ? stepArray : ['']);
    } else {
      setInstructionSteps(['']);
    }

    if (recipe.ingredients && recipe.ingredients.length > 0) {
      setIngredientsList(recipe.ingredients);
    } else {
      setIngredientsList([{ name: '', quantity: '' }]);
    }

    setEditingId(recipe.id);
    setSelectedImage(null); 
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', prepTimeMinutes: 0, cookTimeMinutes: 0, categoryId: 1 });
    setInstructionSteps(['']);
    setIngredientsList([{ name: '', quantity: '' }]); 
    setEditingId(null);
    setSelectedImage(null); 
    setShowForm(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault(); 
    
    const formattedInstructions = instructionSteps
      .filter(step => step.trim() !== '') 
      .map((step, index) => `${index + 1}. ${step}`) 
      .join('\n'); 

    const cleanIngredients = ingredientsList
      .filter(ing => String(ing.name).trim() !== '' && String(ing.quantity).trim() !== '')
      .map(ing => ({
          name: ing.name,
          quantity: parseFloat(ing.quantity) || 0 
      }));

    const recipePayload = {
      ...formData,
      instructions: formattedInstructions,
      ingredients: cleanIngredients
    };

    if (editingId) {
      axios.put(`${API_BASE_URL}/recipes/${editingId}`, recipePayload)
        .then(() => {
          if (selectedImage) {
            const imageFormData = new FormData();
            imageFormData.append('file', selectedImage);
            
            axios.post(`${API_BASE_URL}/recipes/${editingId}/image`, imageFormData, {
              headers: { 'Content-Type': 'multipart/form-data' }
            })
            .then(() => {
              axios.get(`${API_BASE_URL}/recipes`).then(res => setRecipes(res.data));
              resetForm();
            });
          } else {
            axios.get(`${API_BASE_URL}/recipes`).then(res => setRecipes(res.data));
            resetForm();
          }
        })
        .catch(error => {
          console.error("Error updating recipe!", error);
          alert("Failed to update recipe.");
        });
    } else {
      axios.post(`${API_BASE_URL}/recipes`, recipePayload)
        .then(response => {
          const newRecipeId = response.data.id;
          
          if (selectedImage) {
            const imageFormData = new FormData();
            imageFormData.append('file', selectedImage);

            axios.post(`${API_BASE_URL}/recipes/${newRecipeId}/image`, imageFormData, {
              headers: { 'Content-Type': 'multipart/form-data' }
            })
            .then(() => {
              axios.get(`${API_BASE_URL}/recipes`).then(res => setRecipes(res.data));
              resetForm();
            });
          } else {
            axios.get(`${API_BASE_URL}/recipes`).then(res => setRecipes(res.data));
            resetForm();
          }
        })
        .catch(error => {
          console.error("Error creating recipe!", error);
          alert("Failed to create recipe.");
        });
    }
  };

  const handleInstructionChange = (index, value) => {
    const newSteps = [...instructionSteps]; newSteps[index] = value; setInstructionSteps(newSteps);
  };
  const addInstructionRow = () => setInstructionSteps([...instructionSteps, '']);
  const removeInstructionRow = (index) => { if (instructionSteps.length > 1) setInstructionSteps(instructionSteps.filter((_, i) => i !== index)); };

  const handleIngredientChange = (index, field, value) => {
    const newList = [...ingredientsList]; newList[index][field] = value; setIngredientsList(newList);
  };
  const addIngredientRow = () => setIngredientsList([...ingredientsList, { name: '', quantity: '' }]);
  const removeIngredientRow = (index) => { if (ingredientsList.length > 1) setIngredientsList(ingredientsList.filter((_, i) => i !== index)); };

  const filteredRecipes = recipes.filter(recipe => {
    const searchLower = searchTerm.toLowerCase();
    return recipe.title.toLowerCase().includes(searchLower) || (recipe.categoryName && recipe.categoryName.toLowerCase().includes(searchLower));
  });

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} showForm={showForm} resetForm={resetForm} setShowForm={setShowForm} />
        {showForm && (
          <RecipeForm 
            formData={formData} setFormData={setFormData}
            instructionSteps={instructionSteps} handleInstructionChange={handleInstructionChange}
            addInstructionRow={addInstructionRow} removeInstructionRow={removeInstructionRow}
            ingredientsList={ingredientsList} handleIngredientChange={handleIngredientChange}
            addIngredientRow={addIngredientRow} removeIngredientRow={removeIngredientRow}
            setSelectedImage={setSelectedImage} handleSubmit={handleSubmit} editingId={editingId}
          />
        )}
        {loading ? <p className="text-center text-xl text-gray-500">Loading recipes...</p> : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <p className="text-2xl text-gray-500 mb-2">No recipes found </p>
                <p className="text-gray-400">Adjust Your Search Term</p>
              </div>
            ) : filteredRecipes.map((recipe) => (
                <RecipeCard key={recipe.id} recipe={recipe} onEdit={handleEditClick} onDelete={handleDelete} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;