import { useState } from 'react';

function RecipeCard({ recipe, onEdit, onDelete }) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
      
      <div className="h-48 bg-gray-200 w-full overflow-hidden">
        {recipe.imageUrl ? (
          <img 
            src={`http://localhost:5046${recipe.imageUrl}`} 
            alt={recipe.title} 
            className="w-full h-full object-cover" 
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400">
            No Image
          </div>
        )}
      </div>

      <div className="p-5 flex-grow flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-800">{recipe.title}</h3>
          {recipe.categoryName && (
            <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded uppercase">
              {recipe.categoryName}
            </span>
          )}
        </div>

        <p className="text-gray-600 italic mb-4">{recipe.description}</p>

        <div className="mb-4">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full border border-gray-800 text-left px-3 py-2 rounded text-sm font-bold text-gray-800 hover:bg-gray-50 flex justify-between items-center"
          >
            {/* Replaced shapes with standard text arrows */}
            <span>{isExpanded ? 'v Hide Details' : '> View Details'}</span>
          </button>

          {isExpanded && (
            <div className="mt-3 p-4 bg-gray-50 rounded border border-gray-200 text-sm">
              
              <h4 className="font-bold text-gray-800 mb-2 border-b border-gray-300 pb-1">
                Ingredients
              </h4>
              {recipe.ingredients && recipe.ingredients.length > 0 ? (
                <ul className="list-disc pl-5 mb-4 text-gray-700">
                  {recipe.ingredients.map((ing, idx) => (
                    <li key={idx}>
                      <strong>{ing.quantity}</strong> {ing.name}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500 italic mb-4 pl-2">No ingredients listed.</p>
              )}

              <h4 className="font-bold text-gray-800 mb-2 border-b border-gray-300 pb-1">
                Instructions
              </h4>
              <div className="text-gray-700 whitespace-pre-line pl-2">
                {recipe.instructions || "No instructions provided."}
              </div>
            </div>
          )}
        </div>

        <div className="mt-auto border-t pt-4">
          <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
            {/* Removed the clock and fire emojis */}
            <span className="flex items-center gap-1">Prep: {recipe.prepTimeMinutes}m</span>
            <span className="flex items-center gap-1">Cook: {recipe.cookTimeMinutes}m</span>
          </div>

          <div className="flex justify-end gap-2">
            <button
              onClick={() => onEdit(recipe)}
              className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-1.5 px-4 rounded transition-colors"
            >
              Edit
            </button>
            <button
              onClick={() => onDelete(recipe.id)}
              className="bg-red-500 hover:bg-red-600 text-white font-bold py-1.5 px-4 rounded transition-colors"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RecipeCard;