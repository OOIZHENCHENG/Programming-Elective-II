function Header({ searchTerm, setSearchTerm, showForm, resetForm, setShowForm }) {
  return (
    <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
      <h1 className="text-4xl font-bold text-gray-800">Recipe Manager</h1>
      
      <div className="w-full md:w-1/3">
        <input 
          type="text" 
          placeholder="🔍 Search recipes or categories..."
          className="w-full border-2 border-gray-300 p-2 rounded-lg focus:outline-none focus:border-blue-600 shadow-sm transition-colors"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <button 
        onClick={() => { showForm ? resetForm() : setShowForm(true); }}
        className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold transition-colors shadow-md whitespace-nowrap"
      >
        {showForm ? "Cancel" : "+ Add New Recipe"}
      </button>
    </div>
  );
}

export default Header;