function RecipeForm({ 
  formData, setFormData, 
  instructionSteps, handleInstructionChange, addInstructionRow, removeInstructionRow, 
  ingredientsList, handleIngredientChange, addIngredientRow, removeIngredientRow,
  setSelectedImage, handleSubmit, editingId 
}) {
  return (
    <form onSubmit={handleSubmit} className={`bg-white rounded-lg shadow-md p-6 mb-8 grid grid-cols-1 lg:grid-cols-2 gap-8 border-t-4 ${editingId ? 'border-amber-500' : 'border-blue-600'}`}>
      <div className="col-span-1 lg:col-span-2 mb-2">
         {/* Removed pencil and sparkle emojis */}
         <h2 className="text-2xl font-bold text-gray-800">{editingId ? "Edit Recipe" : "Create New Recipe"}</h2>
      </div>

      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-4">
          <h3 className="font-bold text-xl text-gray-800 border-b pb-2">Basic Details</h3>
          <div>
            <label className="block text-gray-700 font-bold mb-1">Recipe Title</label>
            <input type="text" required className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} />
          </div>
          <div>
            <label className="block text-gray-700 font-bold mb-1">Description</label>
            <textarea required rows="2" className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})}></textarea>
          </div>
          <div>
            <label className="block text-gray-700 font-bold mb-1">Meal Category</label>
            <select className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none bg-white" value={formData.categoryId} onChange={(e) => setFormData({...formData, categoryId: parseInt(e.target.value)})}>
              <option value={1}>Breakfast</option><option value={2}>Lunch</option><option value={3}>Dinner</option><option value={4}>Dessert</option><option value={5}>Snacks</option><option value={6}>Beverages</option><option value={7}>Vegan</option><option value={8}>Seafood</option><option value={9}>Appetizers</option><option value={10}>Baking</option><option value={11}>Uncategorized</option>
            </select>
          </div>
          <div className="flex gap-4">
            <div className="w-1/2">
              <label className="block text-gray-700 font-bold mb-1">Prep (mins)</label>
              <input type="number" min="0" required className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={formData.prepTimeMinutes} onChange={(e) => setFormData({...formData, prepTimeMinutes: parseInt(e.target.value) || 0})} />
            </div>
            <div className="w-1/2">
              <label className="block text-gray-700 font-bold mb-1">Cook (mins)</label>
              <input type="number" min="0" required className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={formData.cookTimeMinutes} onChange={(e) => setFormData({...formData, cookTimeMinutes: parseInt(e.target.value) || 0})} />
            </div>
          </div>
          <div className="mt-2">
            <label className="block text-gray-700 font-bold mb-1">Recipe Image (Optional)</label>
            <input type="file" accept="image/*" onChange={(e) => setSelectedImage(e.target.files[0])} className="w-full border p-2 rounded focus:outline-none file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h3 className="font-bold text-xl text-gray-800 border-b pb-2">Ingredients</h3>
          {ingredientsList.map((ing, index) => (
            <div key={index} className="flex gap-2 items-start">
              <input type="text" placeholder="Qty (e.g. 2)" required className="w-1/3 border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={ing.quantity} onChange={(e) => handleIngredientChange(index, 'quantity', e.target.value)} />
              <input type="text" placeholder="Name (e.g. Flour)" required className="w-2/3 border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={ing.name} onChange={(e) => handleIngredientChange(index, 'name', e.target.value)} />
              {ingredientsList.length > 1 && (
                <button type="button" onClick={() => removeIngredientRow(index)} className="bg-red-100 text-red-600 hover:bg-red-200 px-3 py-2 rounded font-bold transition-colors">X</button>
              )}
            </div>
          ))}
          <button type="button" onClick={addIngredientRow} className="mt-1 text-blue-600 hover:text-blue-800 font-bold text-left w-fit flex items-center gap-1"><span>+ Add Ingredient</span></button>
        </div>

        <div className="flex flex-col gap-2">
          <h3 className="font-bold text-xl text-gray-800 border-b pb-2 mt-4">Instructions</h3>
          {instructionSteps.map((step, index) => (
            <div key={index} className="flex gap-2 items-start">
              <span className="bg-blue-100 text-blue-800 font-bold px-3 py-2 rounded">{index + 1}</span>
              <input type="text" placeholder="e.g. Chop the onions..." required className="flex-grow border p-2 rounded focus:ring-2 focus:ring-blue-600 outline-none" value={step} onChange={(e) => handleInstructionChange(index, e.target.value)} />
              {instructionSteps.length > 1 && (
                <button type="button" onClick={() => removeInstructionRow(index)} className="bg-red-100 text-red-600 hover:bg-red-200 px-3 py-2 rounded font-bold transition-colors">X</button>
              )}
            </div>
          ))}
          <button type="button" onClick={addInstructionRow} className="mt-1 text-blue-600 hover:text-blue-800 font-bold text-left w-fit flex items-center gap-1"><span>+ Add Step</span></button>
        </div>
      </div>

      <div className="col-span-1 lg:col-span-2 mt-4">
        {/* Removed floppy disk emojis */}
        <button type="submit" className={`w-full text-white font-bold py-3 rounded-lg transition-colors text-lg shadow-md ${editingId ? 'bg-amber-500 hover:bg-amber-600' : 'bg-green-500 hover:bg-green-600'}`}>
          {editingId ? "Update Existing Recipe" : "Save New Recipe to Database"}
        </button>
      </div>
    </form>
  );
}

export default RecipeForm;