namespace RecipeManagementApi.DTOs.Recipe;

public class IngredientDto
{
    public string Name { get; set; } = string.Empty;
    
    public decimal Quantity { get; set; }
}