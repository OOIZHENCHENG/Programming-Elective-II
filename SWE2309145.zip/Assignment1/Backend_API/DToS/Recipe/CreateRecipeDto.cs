namespace RecipeManagementApi.DTOs.Recipe;

public class CreateRecipeDto
{
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Instructions { get; set; } = string.Empty;
    public int PrepTimeMinutes { get; set; }
    public int CookTimeMinutes { get; set; }
    public int CategoryId { get; set; }
    
    public ICollection<IngredientDto> Ingredients { get; set; } = new List<IngredientDto>();
}