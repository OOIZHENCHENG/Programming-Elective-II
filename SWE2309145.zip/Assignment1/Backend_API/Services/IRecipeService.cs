using RecipeManagementApi.DTOs.Recipe;

namespace RecipeManagementApi.Services;

public interface IRecipeService
{
    Task<IEnumerable<RecipeDto>> GetAllRecipesAsync();
    Task<RecipeDto?> GetRecipeByIdAsync(int id);
    Task<RecipeDto> CreateRecipeAsync(CreateRecipeDto createRecipeDto);
    Task<RecipeDto?> UpdateRecipeAsync(int id, UpdateRecipeDto updateRecipeDto);
    Task<bool> DeleteRecipeAsync(int id);
}