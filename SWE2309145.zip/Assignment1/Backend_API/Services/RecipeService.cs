using RecipeManagementApi.DTOs.Recipe;
using RecipeManagementApi.Models;
using RecipeManagementApi.Repositories;

namespace RecipeManagementApi.Services;

public class RecipeService : IRecipeService
{
    private readonly IRecipeRepository _recipeRepository;

    public RecipeService(IRecipeRepository recipeRepository)
    {
        _recipeRepository = recipeRepository;
    }

    public async Task<IEnumerable<RecipeDto>> GetAllRecipesAsync()
    {
        var recipes = await _recipeRepository.GetAllAsync();
        
        return recipes.Select(r => new RecipeDto
        {
            Id = r.Id, Title = r.Title, Description = r.Description,
            Instructions = r.Instructions, PrepTimeMinutes = r.PrepTimeMinutes,
            CookTimeMinutes = r.CookTimeMinutes, CategoryId = r.CategoryId,
            CategoryName = r.Category?.Name ?? "Uncategorized", ImageUrl = r.ImageUrl,
            Ingredients = r.Ingredients.Select(i => new IngredientDto { Name = i.Name, Quantity = i.Quantity }).ToList() 
        });
    }

    public async Task<RecipeDto?> GetRecipeByIdAsync(int id)
    {
        var recipe = await _recipeRepository.GetByIdAsync(id);
        if (recipe == null) return null;

        return new RecipeDto
        {
            Id = recipe.Id, Title = recipe.Title, Description = recipe.Description,
            Instructions = recipe.Instructions, PrepTimeMinutes = recipe.PrepTimeMinutes,
            CookTimeMinutes = recipe.CookTimeMinutes, CategoryId = recipe.CategoryId,
            CategoryName = recipe.Category?.Name ?? "Uncategorized", ImageUrl = recipe.ImageUrl,
            Ingredients = recipe.Ingredients.Select(i => new IngredientDto { Name = i.Name, Quantity = i.Quantity }).ToList()
        };
    }

    public async Task<RecipeDto> CreateRecipeAsync(CreateRecipeDto dto)
    {
        var recipeModel = new Recipe
        {
            Title = dto.Title, Description = dto.Description, Instructions = dto.Instructions,
            PrepTimeMinutes = dto.PrepTimeMinutes, CookTimeMinutes = dto.CookTimeMinutes, CategoryId = dto.CategoryId,
            
            Ingredients = dto.Ingredients?.Select(i => new Ingredient { 
                Name = i.Name, 
                Quantity = i.Quantity,
                UnitOfMeasure = "" 
            }).ToList() ?? new List<Ingredient>()
        };

        var createdRecipe = await _recipeRepository.CreateAsync(recipeModel);

        return new RecipeDto
        {
            Id = createdRecipe.Id, Title = createdRecipe.Title, Description = createdRecipe.Description,
            Instructions = createdRecipe.Instructions, PrepTimeMinutes = createdRecipe.PrepTimeMinutes,
            CookTimeMinutes = createdRecipe.CookTimeMinutes, CategoryId = createdRecipe.CategoryId, ImageUrl = createdRecipe.ImageUrl,
            Ingredients = createdRecipe.Ingredients.Select(i => new IngredientDto { Name = i.Name, Quantity = i.Quantity }).ToList()
        };
    }

    public async Task<RecipeDto?> UpdateRecipeAsync(int id, UpdateRecipeDto dto)
    {
        var recipeModel = new Recipe
        {
            Title = dto.Title, Description = dto.Description, Instructions = dto.Instructions,
            PrepTimeMinutes = dto.PrepTimeMinutes, CookTimeMinutes = dto.CookTimeMinutes, CategoryId = dto.CategoryId,
            
            Ingredients = dto.Ingredients?.Select(i => new Ingredient { 
                Name = i.Name, 
                Quantity = i.Quantity,
                UnitOfMeasure = "" 
            }).ToList() ?? new List<Ingredient>()
        };

        var updatedRecipe = await _recipeRepository.UpdateAsync(id, recipeModel);
        if (updatedRecipe == null) return null;

        return new RecipeDto
        {
            Id = updatedRecipe.Id, Title = updatedRecipe.Title, Description = updatedRecipe.Description,
            Instructions = updatedRecipe.Instructions, PrepTimeMinutes = updatedRecipe.PrepTimeMinutes,
            CookTimeMinutes = updatedRecipe.CookTimeMinutes, CategoryId = updatedRecipe.CategoryId, ImageUrl = updatedRecipe.ImageUrl,
            Ingredients = updatedRecipe.Ingredients.Select(i => new IngredientDto { Name = i.Name, Quantity = i.Quantity }).ToList()
        };
    }

    public async Task<bool> DeleteRecipeAsync(int id)
    {
        var deletedRecipe = await _recipeRepository.DeleteAsync(id);
        return deletedRecipe != null;
    }
}