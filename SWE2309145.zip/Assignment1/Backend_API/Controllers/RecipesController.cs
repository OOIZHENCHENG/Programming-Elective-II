using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection; 
using RecipeManagementApi.Data;                 
using System.IO;                                
using RecipeManagementApi.DTOs.Recipe;
using RecipeManagementApi.Services;

namespace RecipeManagementApi.Controllers;

[Route("api/[controller]")]
[ApiController]
public class RecipesController : ControllerBase
{
    private readonly IRecipeService _recipeService;

    public RecipesController(IRecipeService recipeService)
    {
        _recipeService = recipeService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var recipes = await _recipeService.GetAllRecipesAsync();
        return Ok(recipes);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var recipe = await _recipeService.GetRecipeByIdAsync(id);
        if (recipe == null) return NotFound(new { message = "Recipe not found." });

        return Ok(recipe);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateRecipeDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState); 

        var createdRecipe = await _recipeService.CreateRecipeAsync(dto);
        
        return CreatedAtAction(nameof(GetById), new { id = createdRecipe.Id }, createdRecipe); 
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateRecipeDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var updatedRecipe = await _recipeService.UpdateRecipeAsync(id, dto);
        if (updatedRecipe == null) return NotFound(new { message = "Recipe not found." });

        return Ok(updatedRecipe);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var success = await _recipeService.DeleteRecipeAsync(id);
        if (!success) return NotFound(new { message = "Recipe not found." });

        return NoContent(); 
    }

    [HttpPost("{id}/image")]
    public async Task<IActionResult> UploadImage(int id, IFormFile file)
    {
        if (file == null || file.Length == 0) return BadRequest("No file uploaded.");

        var recipe = await _recipeService.GetRecipeByIdAsync(id);
        if (recipe == null) return NotFound("Recipe not found.");

        var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
        
        var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
        if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);
        
        var filePath = Path.Combine(folderPath, fileName);

        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await file.CopyToAsync(stream);
        }

        var imageUrl = $"/images/{fileName}";
        
        var dbContext = HttpContext.RequestServices.GetRequiredService<AppDbContext>();
        var dbRecipe = await dbContext.Recipes.FindAsync(id);
        
        if (dbRecipe != null)
        {
            dbRecipe.ImageUrl = imageUrl;
            await dbContext.SaveChangesAsync();
        }

        return Ok(new { ImageUrl = imageUrl });
    }
}