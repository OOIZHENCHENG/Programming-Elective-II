using Microsoft.EntityFrameworkCore;
using RecipeManagementApi.Data;
using RecipeManagementApi.Models;

namespace RecipeManagementApi.Repositories;

public class RecipeRepository : IRecipeRepository
{
    private readonly AppDbContext _context;

    public RecipeRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Recipe>> GetAllAsync()
    {
        return await _context.Recipes.Include(r => r.Category).Include(r => r.Ingredients).ToListAsync();
    }

    public async Task<Recipe?> GetByIdAsync(int id)
    {
        return await _context.Recipes.Include(r => r.Category).Include(r => r.Ingredients).FirstOrDefaultAsync(r => r.Id == id);
    }

    public async Task<Recipe> CreateAsync(Recipe recipe)
    {
        await _context.Recipes.AddAsync(recipe);
        await _context.SaveChangesAsync();
        return recipe;
    }

   public async Task<Recipe?> UpdateAsync(int id, Recipe recipe)
    {
        var existingRecipe = await _context.Recipes
            .Include(r => r.Ingredients)
            .FirstOrDefaultAsync(r => r.Id == id);
        
        if (existingRecipe == null) return null;

        existingRecipe.Title = recipe.Title;
        existingRecipe.Description = recipe.Description;
        existingRecipe.Instructions = recipe.Instructions;
        existingRecipe.PrepTimeMinutes = recipe.PrepTimeMinutes;
        existingRecipe.CookTimeMinutes = recipe.CookTimeMinutes;
        existingRecipe.CategoryId = recipe.CategoryId;

        _context.Ingredients.RemoveRange(existingRecipe.Ingredients);
        await _context.SaveChangesAsync(); 

        foreach (var ingredient in recipe.Ingredients)
        {
            ingredient.RecipeId = existingRecipe.Id; 
            _context.Ingredients.Add(ingredient);
        }
        await _context.SaveChangesAsync(); 

        return existingRecipe;
    }
    public async Task<Recipe?> DeleteAsync(int id)
    {
        var recipe = await _context.Recipes.FirstOrDefaultAsync(r => r.Id == id);
        if (recipe == null) return null;

        _context.Recipes.Remove(recipe);
        await _context.SaveChangesAsync();
        return recipe;
    }
}