using RecipeManagementApi.Models;

namespace RecipeManagementApi.Repositories;

public interface IRecipeRepository
{
    Task<IEnumerable<Recipe>> GetAllAsync();
    Task<Recipe?> GetByIdAsync(int id);
    Task<Recipe> CreateAsync(Recipe recipe);
    Task<Recipe?> UpdateAsync(int id, Recipe recipe);
    Task<Recipe?> DeleteAsync(int id);
}