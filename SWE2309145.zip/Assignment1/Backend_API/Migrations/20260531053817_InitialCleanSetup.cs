﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Backend_API.Migrations
{
    /// <inheritdoc />
    public partial class InitialCleanSetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Recipes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Instructions = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PrepTimeMinutes = table.Column<int>(type: "int", nullable: false),
                    CookTimeMinutes = table.Column<int>(type: "int", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Recipes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Recipes_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Ingredients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Quantity = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    UnitOfMeasure = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RecipeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ingredients", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Ingredients_Recipes_RecipeId",
                        column: x => x.RecipeId,
                        principalTable: "Recipes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Italian" },
                    { 2, "Malaysian" },
                    { 3, "Japanese" },
                    { 4, "Mexican" },
                    { 5, "American" },
                    { 6, "Beverages" },
                    { 7, "Desserts" },
                    { 8, "Soups" },
                    { 9, "Salads" },
                    { 10, "Vegan" }
                });

            migrationBuilder.InsertData(
                table: "Recipes",
                columns: new[] { "Id", "CategoryId", "CookTimeMinutes", "Description", "ImageUrl", "Instructions", "PrepTimeMinutes", "Title" },
                values: new object[,]
                {
                    { 101, 1, 15, "Creamy Italian pasta with bacon.", null, "1. Boil pasta.\n2. Fry bacon.\n3. Mix eggs and cheese.\n4. Combine all.", 10, "Spaghetti Carbonara" },
                    { 102, 2, 30, "Fragrant coconut rice with sambal.", null, "1. Cook rice with coconut milk.\n2. Fry anchovies and peanuts.\n3. Boil eggs.\n4. Serve with sambal.", 15, "Nasi Lemak" },
                    { 103, 3, 20, "Sweet and savory glazed chicken.", null, "1. Pan-fry chicken.\n2. Add teriyaki sauce.\n3. Simmer until thick.", 10, "Chicken Teriyaki" },
                    { 104, 4, 10, "Spicy ground beef in corn shells.", null, "1. Cook ground beef with spices.\n2. Warm taco shells.\n3. Assemble with toppings.", 10, "Beef Tacos" },
                    { 105, 5, 10, "Juicy beef patty with melted cheese.", null, "1. Grill beef patty.\n2. Add cheese to melt.\n3. Toast buns and assemble.", 5, "Classic Cheeseburger" },
                    { 106, 6, 0, "Cold espresso with chocolate and milk.", null, "1. Brew espresso.\n2. Mix with chocolate syrup.\n3. Pour over ice and milk.", 5, "Iced Mocha" },
                    { 107, 7, 25, "Dense and rich chocolate baked dessert.", null, "1. Melt butter and chocolate.\n2. Mix in sugar, eggs, flour.\n3. Bake at 180C for 25 mins.", 15, "Fudge Brownies" },
                    { 108, 8, 20, "Creamy blended earthy soup.", null, "1. Sauté mushrooms and onions.\n2. Add broth and simmer.\n3. Blend with cream.", 10, "Mushroom Soup" },
                    { 109, 9, 0, "Fresh romaine with garlic croutons.", null, "1. Chop lettuce.\n2. Toss with dressing.\n3. Top with parmesan.", 10, "Caesar Salad" },
                    { 110, 10, 0, "Mashed avocado on toasted sourdough.", null, "1. Toast bread.\n2. Mash avocado with lime.\n3. Spread on bread and season.", 5, "Avocado Toast" }
                });

            migrationBuilder.InsertData(
                table: "Ingredients",
                columns: new[] { "Id", "Name", "Quantity", "RecipeId", "UnitOfMeasure" },
                values: new object[,]
                {
                    { 501, "Spaghetti", 200.00m, 101, "grams" },
                    { 502, "Eggs", 2.00m, 101, "pieces" },
                    { 503, "Coconut Milk", 200.00m, 102, "ml" },
                    { 504, "Sambal Paste", 3.00m, 102, "tbsp" },
                    { 505, "Chicken Thigh", 300.00m, 103, "grams" },
                    { 506, "Ground Beef", 250.00m, 104, "grams" },
                    { 507, "Burger Bun", 1.00m, 105, "piece" },
                    { 508, "Espresso Shot", 2.00m, 106, "shots" },
                    { 509, "Cocoa Powder", 50.00m, 107, "grams" },
                    { 510, "Button Mushrooms", 300.00m, 108, "grams" },
                    { 511, "Romaine Lettuce", 1.00m, 109, "head" },
                    { 512, "Avocado", 1.00m, 110, "piece" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Ingredients_RecipeId",
                table: "Ingredients",
                column: "RecipeId");

            migrationBuilder.CreateIndex(
                name: "IX_Recipes_CategoryId",
                table: "Recipes",
                column: "CategoryId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Ingredients");

            migrationBuilder.DropTable(
                name: "Recipes");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
