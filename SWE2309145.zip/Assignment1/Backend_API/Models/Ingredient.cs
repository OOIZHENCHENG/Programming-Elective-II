namespace RecipeManagementApi.Models;

public class Ingredient
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    
    public decimal Quantity { get; set; } 
    
    public string UnitOfMeasure { get; set; } = string.Empty; 
    public int RecipeId { get; set; }
}