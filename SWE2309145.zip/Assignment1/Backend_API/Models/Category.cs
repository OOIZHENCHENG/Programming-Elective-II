using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace RecipeManagementApi.Models;

public class Category
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Category Name is required.")]
    [MaxLength(50, ErrorMessage = "Category Name cannot exceed 50 characters.")]
    public string Name { get; set; } = string.Empty;

    [JsonIgnore]
    public ICollection<Recipe> Recipes { get; set; } = new List<Recipe>();
}