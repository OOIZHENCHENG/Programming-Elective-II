using System.ComponentModel.DataAnnotations; 
namespace RecipeManagementApi.Models;

public class Recipe
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Recipe Title is strictly required.")]
    [MaxLength(100, ErrorMessage = "Title cannot exceed 100 characters.")]
    public string Title { get; set; } = string.Empty;

    [MaxLength(500, ErrorMessage = "Description cannot exceed 500 characters.")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Instructions are required.")]
    public string Instructions { get; set; } = string.Empty;

    [Range(0, 1440, ErrorMessage = "Prep time must be between 0 and 1440 minutes.")]
    public int PrepTimeMinutes { get; set; }

    [Range(0, 1440, ErrorMessage = "Cook time must be between 0 and 1440 minutes.")]
    public int CookTimeMinutes { get; set; }

    [Required]
    public int CategoryId { get; set; }

    public string? ImageUrl { get; set; }

    public Category? Category { get; set; }
    
    public ICollection<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
}