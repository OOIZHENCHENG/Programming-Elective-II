using Microsoft.EntityFrameworkCore;
using RecipeManagementApi.Models;

namespace RecipeManagementApi.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Recipe> Recipes => Set<Recipe>();
    public DbSet<Ingredient> Ingredients => Set<Ingredient>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    base.OnModelCreating(modelBuilder);

    // 1. Seed Categories (10 Rows for Rubric)
    modelBuilder.Entity<Category>().HasData(
        new Category { Id = 1, Name = "Italian" },
        new Category { Id = 2, Name = "Malaysian" },
        new Category { Id = 3, Name = "Japanese" },
        new Category { Id = 4, Name = "Mexican" },
        new Category { Id = 5, Name = "American" },
        new Category { Id = 6, Name = "Beverages" },
        new Category { Id = 7, Name = "Desserts" },
        new Category { Id = 8, Name = "Soups" },
        new Category { Id = 9, Name = "Salads" },
        new Category { Id = 10, Name = "Vegan" }
    );

    // 2. Seed Recipes (10 Rows for Rubric)
    modelBuilder.Entity<Recipe>().HasData(
        new Recipe { Id = 101, Title = "Spaghetti Carbonara", Description = "Creamy Italian pasta with bacon.", Instructions = "1. Boil pasta.\n2. Fry bacon.\n3. Mix eggs and cheese.\n4. Combine all.", PrepTimeMinutes = 10, CookTimeMinutes = 15, CategoryId = 1 },
        new Recipe { Id = 102, Title = "Nasi Lemak", Description = "Fragrant coconut rice with sambal.", Instructions = "1. Cook rice with coconut milk.\n2. Fry anchovies and peanuts.\n3. Boil eggs.\n4. Serve with sambal.", PrepTimeMinutes = 15, CookTimeMinutes = 30, CategoryId = 2 },
        new Recipe { Id = 103, Title = "Chicken Teriyaki", Description = "Sweet and savory glazed chicken.", Instructions = "1. Pan-fry chicken.\n2. Add teriyaki sauce.\n3. Simmer until thick.", PrepTimeMinutes = 10, CookTimeMinutes = 20, CategoryId = 3 },
        new Recipe { Id = 104, Title = "Beef Tacos", Description = "Spicy ground beef in corn shells.", Instructions = "1. Cook ground beef with spices.\n2. Warm taco shells.\n3. Assemble with toppings.", PrepTimeMinutes = 10, CookTimeMinutes = 10, CategoryId = 4 },
        new Recipe { Id = 105, Title = "Classic Cheeseburger", Description = "Juicy beef patty with melted cheese.", Instructions = "1. Grill beef patty.\n2. Add cheese to melt.\n3. Toast buns and assemble.", PrepTimeMinutes = 5, CookTimeMinutes = 10, CategoryId = 5 },
        new Recipe { Id = 106, Title = "Iced Mocha", Description = "Cold espresso with chocolate and milk.", Instructions = "1. Brew espresso.\n2. Mix with chocolate syrup.\n3. Pour over ice and milk.", PrepTimeMinutes = 5, CookTimeMinutes = 0, CategoryId = 6 },
        new Recipe { Id = 107, Title = "Fudge Brownies", Description = "Dense and rich chocolate baked dessert.", Instructions = "1. Melt butter and chocolate.\n2. Mix in sugar, eggs, flour.\n3. Bake at 180C for 25 mins.", PrepTimeMinutes = 15, CookTimeMinutes = 25, CategoryId = 7 },
        new Recipe { Id = 108, Title = "Mushroom Soup", Description = "Creamy blended earthy soup.", Instructions = "1. Sauté mushrooms and onions.\n2. Add broth and simmer.\n3. Blend with cream.", PrepTimeMinutes = 10, CookTimeMinutes = 20, CategoryId = 8 },
        new Recipe { Id = 109, Title = "Caesar Salad", Description = "Fresh romaine with garlic croutons.", Instructions = "1. Chop lettuce.\n2. Toss with dressing.\n3. Top with parmesan.", PrepTimeMinutes = 10, CookTimeMinutes = 0, CategoryId = 9 },
        new Recipe { Id = 110, Title = "Avocado Toast", Description = "Mashed avocado on toasted sourdough.", Instructions = "1. Toast bread.\n2. Mash avocado with lime.\n3. Spread on bread and season.", PrepTimeMinutes = 5, CookTimeMinutes = 0, CategoryId = 10 }
    );

    // 3. Seed Ingredients (Child Data)
    modelBuilder.Entity<Ingredient>().HasData(
        new Ingredient { Id = 501, RecipeId = 101, Name = "Spaghetti", Quantity = 200.00m, UnitOfMeasure = "grams" },
        new Ingredient { Id = 502, RecipeId = 101, Name = "Eggs", Quantity = 2.00m, UnitOfMeasure = "pieces" },
        new Ingredient { Id = 503, RecipeId = 102, Name = "Coconut Milk", Quantity = 200.00m, UnitOfMeasure = "ml" },
        new Ingredient { Id = 504, RecipeId = 102, Name = "Sambal Paste", Quantity = 3.00m, UnitOfMeasure = "tbsp" },
        new Ingredient { Id = 505, RecipeId = 103, Name = "Chicken Thigh", Quantity = 300.00m, UnitOfMeasure = "grams" },
        new Ingredient { Id = 506, RecipeId = 104, Name = "Ground Beef", Quantity = 250.00m, UnitOfMeasure = "grams" },
        new Ingredient { Id = 507, RecipeId = 105, Name = "Burger Bun", Quantity = 1.00m, UnitOfMeasure = "piece" },
        new Ingredient { Id = 508, RecipeId = 106, Name = "Espresso Shot", Quantity = 2.00m, UnitOfMeasure = "shots" },
        new Ingredient { Id = 509, RecipeId = 107, Name = "Cocoa Powder", Quantity = 50.00m, UnitOfMeasure = "grams" },
        new Ingredient { Id = 510, RecipeId = 108, Name = "Button Mushrooms", Quantity = 300.00m, UnitOfMeasure = "grams" },
        new Ingredient { Id = 511, RecipeId = 109, Name = "Romaine Lettuce", Quantity = 1.00m, UnitOfMeasure = "head" },
        new Ingredient { Id = 512, RecipeId = 110, Name = "Avocado", Quantity = 1.00m, UnitOfMeasure = "piece" }
    );
}
}