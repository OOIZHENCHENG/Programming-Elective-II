using Microsoft.EntityFrameworkCore;
using RecipeManagementApi.Data;
using RecipeManagementApi.Repositories;
using RecipeManagementApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp", builder =>
    {
        builder.WithOrigins("http://localhost:5173") // Your React Vite port
               .AllowAnyHeader()
               .AllowAnyMethod();
    });
});

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<IRecipeRepository, RecipeRepository>();

builder.Services.AddScoped<IRecipeService, RecipeService>();

var app = builder.Build();

app.UseCors("AllowReactApp");

app.UseStaticFiles();

app.UseAuthorization();
app.MapControllers();

app.Run();