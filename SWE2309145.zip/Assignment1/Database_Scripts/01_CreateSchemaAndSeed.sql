
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'RecipeManagementDB')
BEGIN
    ALTER DATABASE RecipeManagementDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RecipeManagementDB;
END
GO

CREATE DATABASE RecipeManagementDB;
GO

USE RecipeManagementDB;
GO


-- Table A: Categories
CREATE TABLE Categories (
    Id INT IDENTITY(1,1) NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    
    CONSTRAINT PK_Categories PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Category_Name UNIQUE (Name)
);

-- Table B: Recipes
CREATE TABLE Recipes (
    Id INT IDENTITY(1,1) NOT NULL,
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(500) NULL,
    Instructions NVARCHAR(MAX) NOT NULL,
    PrepTimeMinutes INT NOT NULL DEFAULT 0,
    CookTimeMinutes INT NOT NULL DEFAULT 0,
    CategoryId INT NOT NULL,
    
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdatedAt DATETIME2 NULL,

    CONSTRAINT PK_Recipes PRIMARY KEY CLUSTERED (Id),
    
    -- FIXED: Removed the accidental 'CONSTRAINT' word here
    CONSTRAINT FK_Recipes_Categories FOREIGN KEY (CategoryId) 
        REFERENCES Categories(Id) ON DELETE NO ACTION, 
    
    CONSTRAINT CK_Recipes_PrepTime CHECK (PrepTimeMinutes >= 0),
    CONSTRAINT CK_Recipes_CookTime CHECK (CookTimeMinutes >= 0)
);

-- Table C: Ingredients
CREATE TABLE Ingredients (
    Id INT IDENTITY(1,1) NOT NULL,
    RecipeId INT NOT NULL,
    Name NVARCHAR(150) NOT NULL,
    Quantity DECIMAL(6,2) NOT NULL, 
    UnitOfMeasure NVARCHAR(50) NOT NULL, 

    CONSTRAINT PK_Ingredients PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_Ingredients_Recipes FOREIGN KEY (RecipeId) 
        REFERENCES Recipes(Id) ON DELETE CASCADE,
        
    CONSTRAINT CK_Ingredients_Quantity CHECK (Quantity > 0) 
);
GO

-- 3. PERFORMANCE INDEXING STRATEGY
CREATE NONCLUSTERED INDEX IX_Recipes_CategoryId ON Recipes(CategoryId);
CREATE NONCLUSTERED INDEX IX_Ingredients_RecipeId ON Ingredients(RecipeId);
CREATE NONCLUSTERED INDEX IX_Recipes_Title ON Recipes(Title);
GO


-- 4. COMPREHENSIVE SEED DATA
INSERT INTO Categories (Name) VALUES 
('Italian'), ('Malaysian'), ('Japanese'), ('Mexican'), ('American'), 
('Beverages'), ('Desserts'), ('Soups'), ('Salads'), ('Vegan');

INSERT INTO Recipes (Title, Description, Instructions, PrepTimeMinutes, CookTimeMinutes, CategoryId) VALUES
('Spaghetti Carbonara', 'Creamy Italian pasta with bacon.', '1. Boil pasta. 2. Fry bacon. 3. Mix eggs and cheese. 4. Combine all.', 10, 15, 1),
('Nasi Lemak', 'Fragrant coconut rice with sambal.', '1. Cook rice with coconut milk. 2. Fry anchovies and peanuts. 3. Boil eggs. 4. Serve with sambal.', 15, 30, 2),
('Chicken Teriyaki', 'Sweet and savory glazed chicken.', '1. Pan-fry chicken. 2. Add teriyaki sauce. 3. Simmer until thick.', 10, 20, 3),
('Beef Tacos', 'Spicy ground beef in corn shells.', '1. Cook ground beef with spices. 2. Warm taco shells. 3. Assemble with toppings.', 10, 10, 4),
('Classic Cheeseburger', 'Juicy beef patty with melted cheese.', '1. Grill beef patty. 2. Add cheese to melt. 3. Toast buns and assemble.', 5, 10, 5),
('Iced Mocha', 'Cold espresso with chocolate and milk.', '1. Brew espresso. 2. Mix with chocolate syrup. 3. Pour over ice and milk.', 5, 0, 6),
('Fudge Brownies', 'Dense and rich chocolate baked dessert.', '1. Melt butter and chocolate. 2. Mix in sugar, eggs, flour. 3. Bake at 180C for 25 mins.', 15, 25, 7),
('Mushroom Soup', 'Creamy blended earthy soup.', '1. Sauté mushrooms and onions. 2. Add broth and simmer. 3. Blend with cream.', 10, 20, 8),
('Caesar Salad', 'Fresh romaine with garlic croutons.', '1. Chop lettuce. 2. Toss with dressing. 3. Top with parmesan.', 10, 0, 9),
('Avocado Toast', 'Mashed avocado on toasted sourdough.', '1. Toast bread. 2. Mash avocado with lime. 3. Spread on bread and season.', 5, 0, 10);

INSERT INTO Ingredients (RecipeId, Name, Quantity, UnitOfMeasure) VALUES
(1, 'Spaghetti', 200.00, 'grams'),
(1, 'Eggs', 2.00, 'pieces'),
(2, 'Coconut Milk', 200.00, 'ml'),
(2, 'Sambal Paste', 3.00, 'tbsp'),
(3, 'Chicken Thigh', 300.00, 'grams'),
(4, 'Ground Beef', 250.00, 'grams'),
(5, 'Burger Bun', 1.00, 'piece'),
(6, 'Espresso Shot', 2.00, 'shots'),
(7, 'Cocoa Powder', 50.00, 'grams'),
(8, 'Button Mushrooms', 300.00, 'grams'),
(9, 'Romaine Lettuce', 1.00, 'head'),
(10, 'Avocado', 1.00, 'piece');
GO